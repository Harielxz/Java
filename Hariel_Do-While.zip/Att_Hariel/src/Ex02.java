import java.util.Scanner;

public class Ex02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		
		int codigoCidade, numVeiculoPass = 0, AcidentesVitima = 0, i = 0,  mediavit = 0;
		
		do {
			
			System.out.println("Qual � o c�digo da sua cidade:");
			codigoCidade = sc.nextInt();
			
			System.out.println("Qual � o n�mero de ve�culos de passeio:");
			numVeiculoPass = sc.nextInt();
			
			System.out.println("Qual � o n�mero de acidentes com vitimas:");
			AcidentesVitima = sc.nextInt();
			
			mediavit += AcidentesVitima;
			
			if(codigoCidade > AcidentesVitima) {
				System.out.println("A cidade do c�digo "+ codigoCidade + " teve o maior indice de acidente");
			}
			
			if(mediavit < 2000) {
				System.out.println("A m�dia de acidentes de tr�nsito foi de: " +mediavit/5);
			}
			
			System.out.println("A m�dia de ve�culos das 5 cidades foi de: " + numVeiculoPass/5);
			
			i++;
		}while (i <= 5);

		sc.close();
	}		

}