import java.util.Scanner;

public class Ex01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		
		int num1, n = 0;
		
		do {
			n = 0;
			System.out.println("Digite um n�mero:");
			num1 = sc.nextInt();
			
			if(num1 <= 1) {
				break;
			}
			
			for(int i = num1; i >= 1; i--) {
				if(num1%i == 0){
				  n++;	
				}
			}
			
			if(n == 2 ) {
				System.out.println("O n�mero digitado � primo !");
			}else {
				System.out.println("O n�mero digitado n�o � primo !");
			}
		}while (num1 > 1);
		
		sc.close();

	}		

}
