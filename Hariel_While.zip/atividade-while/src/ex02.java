import java.util.Scanner;

public class ex02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		int valor = 0;
		
		System.out.println("Informe um n�mero !!");
		valor = sc.nextInt();
		
		System.out.println("N�mero ao quadrado: " + valor*valor);
		System.out.println("N�mero ao cubo: " + valor*valor*valor);
		System.out.println("Raiz quadrada do n�mero: " + Math.sqrt(valor));
		
		while(valor <0) {
			System.out.println("N�mero inv�lido !!");
			System.out.println("Informe outro n�mero !!");
		}
		
		
		sc.close();

	}

}
