import java.util.Scanner;

public class ex03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        int valor;
		
		System.out.println("Informe um n�mero !!");
		valor = sc.nextInt();
		
		if (valor <= 0 ) {
			System.out.println("N�mero inv�lido");
		}
		
		if (valor > 0 ) {
			System.out.println("Soma dos n�meros: " + (valor+valor));
			System.out.println("Quantidade de n�meros digitados: " +valor);
		}
		
		
		
		sc.close();
	}

}
