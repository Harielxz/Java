import java.util.Scanner;
public class Main {

public static void main(String[] args) {		
				
Scanner sc = new Scanner(System.in);
				
int menu;
double num1 ,num2 ,num3 ,num4 ,num5,soma;
				
System.out.println("<--===    ===-->");
System.out.println("Menu de op��es:" + 
"\n 1 - Soma"                        +
"\n 2 - Multiplica��o"               + 
"\n 3 - Divis�o"                     +
"\n 4 - Subtra��o"                   + 
"\n 5 - Potencia��o"                 + 
"\n 6 - Porcentagem"                 + 
"\n 7 - Raiz Quadrada");
menu = sc.nextInt();
				

    if (menu == 1) {
					
 System.out.println("Informe um n�mero");
 num1 = sc.nextDouble();

 System.out.println("Informe um n�mero");
 num2 = sc.nextDouble();

 System.out.println("Informe um n�mero");
 num3 = sc.nextDouble();
					
 System.out.println("Informe um n�mero");
 num4 = sc.nextDouble();
					
 System.out.println("Informe um n�mero");
 num5 = sc.nextDouble();
					
 System.out.println("Soma = " 
                     +(num1 
		             + num2 
		             + num3 
		             + num4 
		             + num5));
}
				

    
    if(menu == 2) {
					
 System.out.println("Informe um n�mero  ");
 num1 = sc.nextDouble();

 System.out.println("Informe um n�mero  ");
 num2 = sc.nextDouble();

 System.out.println("Informe um n�mero  ");
 num3 = sc.nextDouble();
					
 System.out.println("Informe um n�mero  ");
 num4 = sc.nextDouble();
					
 System.out.println("Informe um n�mero  ");
 num5 = sc.nextDouble();
					
 System.out.println("Multiplica��o = " 
                      +(num1  
                      * num2 
                      * num3 
                      * num4 
                      * num5));
}
				
  if(menu == 3) {
					
 System.out.println("Informe um n�mero  ");
 num1 = sc.nextDouble();

 System.out.println("Informe um n�mero  ");
 num2 = sc.nextDouble();

 System.out.println("Informe um n�mero  ");
 num3 = sc.nextDouble();
					
 System.out.println("Informe um n�mero  ");
 num4 = sc.nextDouble();
					
 System.out.println("Informe um n�mero  ");
 num5 = sc.nextDouble();
					
 System.out.println("Divis�o = " 
                      +(num1
                      / num2
                      / num3
                      / num4
                      / num5));
}
				
if (menu == 4) {
						
 System.out.println("Informe um n�mero  ");
 num1 = sc.nextDouble();

 System.out.println("Informe um n�mero  ");
 num2 = sc.nextDouble();
 
 System.out.println("Informe um n�mero  ");
 num3 = sc.nextDouble();
							
 System.out.println("Informe um n�mero  ");
 num4 = sc.nextDouble();
							
 System.out.println("Informe um n�mero  ");
 num5 = sc.nextDouble();
							
 System.out.println("Subtra��o = " + (num1 - num2 - num3 - num4 - num5));
							
}
						
if(menu == 5) {
							
 System.out.println("Informe um n�mero  ");
 num1 = sc.nextDouble();

 System.out.println("Informe um n�mero  ");
 num2 = sc.nextDouble();

 System.out.println("Informe um n�mero  ");
 num3 = sc.nextDouble();
							
 System.out.println("Informe um n�mero  ");
 num4 = sc.nextDouble();
							
 System.out.println("Informe um n�mero  ");
 num5 = sc.nextDouble();
							
 soma = num1
	  + num2
	  + num3
	  + num4
	  + num5;
							
 System.out.println("Potencia = " + Math.pow(soma,soma));
}
						
if(menu == 6) {
							
 System.out.println("Informe um n�mero  ");
 num1 = sc.nextDouble();

 System.out.println("Informe um n�mero  ");
 num2 = sc.nextDouble();

 System.out.println("Informe um n�mero  ");
 num3 = sc.nextDouble();
							
 System.out.println("Informe um n�mero  ");
 num4 = sc.nextDouble();
							
 System.out.println("Informe um n�mero  ");
 num5 = sc.nextDouble();
							
 soma =   num1
		+ num2
		+ num3
		+ num4
	    + num5;
							
System.out.println("Porcentagem = " + (soma/100));
}
					
if(menu == 7) {
							
 System.out.println("Informe um n�mero  ");
 num1 = sc.nextDouble();

 System.out.println("Informe um n�mero  ");
 num2 = sc.nextDouble();
 
 System.out.println("Informe um n�mero  ");
 num3 = sc.nextDouble();
							
 System.out.println("Informe um n�mero  ");
 num4 = sc.nextDouble();
							
 System.out.println("Informe um n�mero  ");
 num5 = sc.nextDouble();
						
soma = num1
     + num2
     + num3
     + num4
     + num5;
      					
System.out.println("Raiz Quadrada = " + Math.sqrt(soma));
}				
sc.close();
}
}