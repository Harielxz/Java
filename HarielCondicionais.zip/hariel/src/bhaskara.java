import java.util.Scanner;
public class bhaskara {

	public static void main(String[] args) {
		int a,b,c;
		double delta,x1,x2;
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Informe o (x�) valor de a:");
		a = sc.nextInt();
		System.out.println("Informe o (x) valor de b:");
		b = sc.nextInt();
		System.out.println("Informe o valor de c:");
		c = sc.nextInt();
		
		// Delta = b� + 4.a.c
	 
		delta =(Math.pow(b, 2)) - (-4*a*c);
        x1 = -b + Math.sqrt(delta) / (2*a);
        x2 = -b - Math.sqrt(delta) / (2*a);
        
        System.out.printf("O valor do seu delta �: %.2f" ,delta);
        System.out.printf("\nO x� de sua equa��o �: %.2f " ,x1);
        System.out.printf("\nO x� de sua equa��o �: %2.f" ,x2);
        
        sc.close();
		
	}

}
