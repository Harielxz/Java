import java.util.Scanner;
public class exerc01 {

	public static void main(String[] args) {
		
	    Scanner sc = new Scanner(System.in);
		double n1,n2,n3,concFinal;
		
		System.out.println("Informe a sua primeira Nota: ");
		n1 = sc.nextDouble();
		
		n1 = n1*2;
		
		System.out.println("Informe a sua segunda Nota: ");
		n2 = sc.nextDouble();
		
		n2=n2*3;
		
		System.out.println("Informe a sua terceira Nota: ");
		n3 = sc.nextDouble();
		
		n3=n3*5;
		
		concFinal= (n1+n2+n3)/10;
		
		if (concFinal>8 && concFinal<=10) {
			System.out.println("Seu conceito final � A");
			sc.close();
		}
		
		if (concFinal>7 && concFinal<=8) {
			System.out.println("Seu conceito final � B");
			sc.close();
		
	}
		if (concFinal>6 && concFinal<=7) {
			System.out.println("Seu conceito final � C");
			sc.close();
		}
				if (concFinal>5 && concFinal<=6) {
					System.out.println("Seu conceito final � D");
					sc.close();
			}
				if (concFinal>0 && concFinal<5) {
					System.out.println("Seu conceito final � E");
					sc.close();
				}
				
					
					
				
	}
}
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					