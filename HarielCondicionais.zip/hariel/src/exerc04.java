import java.util.Scanner;
public class exerc04 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		double num01,num02,num03;
		
		System.out.println("Informe o primeiro n�mero!");
		num01 = sc.nextDouble();
		
		System.out.println("Informe o segundo n�mero!");
		num02 = sc.nextDouble();
		
		System.out.println("Informe o terceiro n�mero!");
		num03 = sc.nextDouble();
		
		// DIGITE OS TR�S N�MEROS DIFERENTES !!
		
		if(num01 > num02 && num01>num03) {
			System.out.println("Primeiro: " + num01 + "Segundo: " + num02 + "Terceiro: " + num03);
			sc.close();
		} 
	}

}
