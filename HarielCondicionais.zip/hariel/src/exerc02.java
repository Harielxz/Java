import java.util.Scanner;
public class exerc02 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		double n1,n2,n3,m�dia,exame=6;
		
		System.out.println("Informe sua primeira nota!");
		n1 = sc.nextDouble();
		
		System.out.println("Informe sua segunda nota!");
		n2 = sc.nextDouble();
		
		System.out.println("Informe sua terceira nota!");
		n3 = sc.nextDouble();

		m�dia = (n1+n2+n3) / 3;
		exame = 6 - m�dia;
		
		if(m�dia>0 && m�dia<=3) {
			System.out.println("Voc� est� reprovado!!");
			
			sc.close();
		}
		
		if(m�dia>3 && m�dia<=7) {
			System.out.println("Voc� est� em exame!!");
			System.out.println("Voc� precisa de " + exame);
			sc.close();
		}
		
		if(m�dia>7 && m�dia<=10) {
			System.out.println("Voc� est� aprovado!!");
			sc.close();
		}
	}

}
