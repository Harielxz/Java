import java.util.Scanner;
public class exerc03 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
	
        double num01,num02;
        
        System.out.println("Informe o primeiro n�mero!!");
        num01 = sc.nextDouble();
        
        System.out.println("Informe o segundo n�mero!!");
        num02 = sc.nextDouble();
        
        if(num01>num02) {
        	System.out.println("O primeiro n�mero � maior que o segundo!!");
        	sc.close();
        }
        
        if(num02>num01) {
        	System.out.println("O segundo n�mero � maior que o primeiro!!");
        	sc.close();
        }
        
        }

}
