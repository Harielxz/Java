import java.util.Scanner;

public class Ex02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		double altura = 0, peso = 0, mediaAltura = 0, mediaIdade = 0, mediaIdadePeso = 0,quantAltura = 0;
		int x = 0, y = 0, quantIdadeInferior = 0, quantIdade = 0, idade;
		
		
		System.out.println("1) Digite o valor para x times: ");
		x = sc.nextInt();		
		System.out.println("2) Digite o valor para y jogadores: ");
		y = sc.nextInt();
			
			for(int i=1; i<=x; i++){
			for (int j = 1; j<=y; j++){ 
				System.out.println("3) Digite a idade do jogador " + "["+ j + "] do time " + "["+ i + "]");
				idade = sc.nextInt();
				System.out.println("4) Digite o peso do jogador " + "["+ j + "] do time " + "["+ i + "]");
				peso = sc.nextDouble();
				System.out.println("5) Digite a altura do jogador " + "["+ j + "] do time " + "["+ i + "]");
				altura = sc.nextDouble();
					
		
		if(idade <=18 ){
			quantIdadeInferior++;
		}
		
	
		quantIdade = quantIdade + idade;
		mediaIdade = quantIdade/y;
		

		quantAltura = quantAltura + altura;
		mediaAltura = quantAltura/y;
		
		}
			System.out.println("\n>>> A m�dia de jogadores com peso acima de 80: "+ mediaIdadePeso);		
			System.out.println("\n>>> A m�dia de idades dos jogadores: "+ mediaIdade);
			System.out.println("\n>>> A m�dia de alturas dos jogadores: "+ mediaAltura);		
		    System.out.println("\n>>> A quantidade de jogadores de todos os times com idade inferior a 18 anos �: "+ quantIdadeInferior);
		    
		    sc.close();
	
		}
	}
		
		
		}
		
		


