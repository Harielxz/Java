import java.util.Scanner;
public class Ex01 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
				
		System.out.println("Informe um n�mero: ");
		int entrada = sc.nextInt();
		
		int multiplicador = 0;
		
		while(multiplicador <=10) {
			int resultado = entrada * multiplicador;
			System.out.println(entrada+" x " + multiplicador+ " = " +resultado);
		
			multiplicador++;
		}
	
		sc.close();
	}
	
}
