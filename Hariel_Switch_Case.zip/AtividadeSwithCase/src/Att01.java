import java.util.Scanner;
public class Att01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	
	double salarioAtual=0;
	
	System.out.println("Informe o c�digo do seu cargo");
	int codigo = sc.nextInt();
	
	switch(codigo) {
	
	case 1:
	System.out.println("Seu cargo � Escritur�rio");
	System.out.println("Informe o valor do seu s�lario:");
    salarioAtual = sc.nextDouble();
	System.out.println("Novo s�lario " + (salarioAtual * 0.50 + salarioAtual));
 break;
 
	case 2:
	System.out.println("Seu cargo � Secret�rio");
	System.out.println("Informe o valor do seu s�lario:");
    salarioAtual = sc.nextDouble();
	System.out.println("Novo s�lario " + (salarioAtual * 0.35 + salarioAtual));
break;

	case 3:
	System.out.println("Seu cargo � Caixa");
	System.out.println("Informe o valor do seu s�lario:");
    salarioAtual = sc.nextDouble();
	System.out.println("Novo s�lario " + (salarioAtual * 0.20 + salarioAtual));
break;

	case 4:
	System.out.println("Seu cargo � Gerente");
	System.out.println("Informe o valor do seu s�lario:");
    salarioAtual = sc.nextDouble();
	System.out.println("Novo s�lario " + (salarioAtual * 0.10 + salarioAtual));
break;

	case 5:
	System.out.println("Seu cargo � Diretor");
	System.out.println("Voc� n�o ir� receber aumento !!");
break;	

}
	
		sc.close();
	
	}

}
