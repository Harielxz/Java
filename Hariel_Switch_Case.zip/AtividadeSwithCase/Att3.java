import java.util.Scanner;
public class Att3 {

	public static void main(String[] args) {
	
Scanner sc = new Scanner (System.in);
 int quantidade = 0,crit�rioA = 0,crit�rioB = 0;

System.out.println("Quantos livros voc� deseja comprar ?? ");
sc.nextInt();

System.out.println("Qual crit�rio voc� deseja obter ? " );

switch (crit�rioA) {
case 1:
	System.out.println("O valor a ser pago � " + (0.50 * quantidade + 2.50));
	crit�rioA = sc.nextInt();
break;

case 2:
	System.out.println("O valor a ser pago � " + (0.50 * quantidade + 2.50));
	crit�rioA = sc.nextInt();
break;

case 3:
	System.out.println("O valor a ser pago � " + (0.50 * quantidade + 2.50));
	crit�rioA = sc.nextInt();
break;

case 4:
	System.out.println("O valor a ser pago � " + (0.50 * quantidade + 2.50));
	crit�rioA = sc.nextInt();
break;

case 5:
	System.out.println("O valor a ser pago � " + (0.50 * quantidade + 2.50));
	crit�rioA = sc.nextInt();
break;

}

switch(crit�rioB) {

case 1:
	System.out.println("O valor a ser pago � " + (0.25 * quantidade + 7.50));
	crit�rioB = sc.nextInt();
break;

case 2:
	System.out.println("O valor a ser pago � " + (0.25 * quantidade + 7.50));
	crit�rioB = sc.nextInt();
break;

case 3:
	System.out.println("O valor a ser pago � " + (0.25 * quantidade + 7.50));
	crit�rioB = sc.nextInt();
break;

case 4:
	System.out.println("O valor a ser pago � " + (0.25 * quantidade + 7.50));
	crit�rioB = sc.nextInt();
break;

case 5:
	System.out.println("O valor a ser pago � " + (0.25 * quantidade + 7.50));
	crit�rioB = sc.nextInt();
break;

}
sc.close();
		  

	}

}
